# README #


## Modification

Files `wdev-ui.css` and `wdev-ui.js` contain the new WPMUDEV-style UI definitions and can be updated if needed.

**Tip:** Those files are loaded after the notice-files below to ensure that notice definitions can be overwritten by wdev-ui files.


## Do not edit

Do not modify the files `notice.css` and `notice.js` - those files are also used by a lot of other plugins. If they are changed they also need to be modified in submodule `incsub/free-dashboard` and all related plugins need to be updated.